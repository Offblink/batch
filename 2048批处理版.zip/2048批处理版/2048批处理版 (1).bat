@echo off
title ��2048�Ĺ���һ����������d���ͻ�ʤ
setlocal enabledelayedexpansion
:return
for /f "tokens=1 delims=;" %%i in (save.wc) do set bestscore=%%i
set score=0

set nb=0
:back
set /a nb+=1
set a%nb%=��
if %nb% == 16 goto next
goto back

:next
set nb=0
:backnext
set /a nb+=1
if !a%nb%! == �� goto next2
if %nb% == 16 goto check
goto backnext
:next2

cls
set /a location=%random%%%16+1
if not !a%location%! == �� goto next
set a%location%=��
echo Ŀǰ�÷֣�%score%
echo ��ߵ÷֣�%bestscore%
echo.
echo %a1%  %a2%  %a3%  %a4%
echo.
echo %a5%  %a6%  %a7%  %a8%
echo.
echo %a9%  %a10%  %a11%  %a12%
echo.
echo %a13%  %a14%  %a15%  %a16%
echo.
set nb=0
:backnext2
set /a nb+=1
if !a%nb%! == �d echo ��ϲͨ�أ�&goto check
if %nb% == 16 goto next3
goto backnext2
:next3
choice /c wsad /n
if %errorlevel% == 1 goto up
if %errorlevel% == 2 goto down
if %errorlevel% == 3 goto left
if %errorlevel% == 4 goto right

:up
set nb=0
:backup
set /a nb+=1
if %nb% == 17 goto next
if !a%nb%! == �� goto backup
set mid=%nb%
:loopup
set /a upnb=%nb%-4
if !a%upnb%! == �� set nb=%upnb%&goto loopup
if not %mid% == %nb% set a%nb%=!a%mid%!&set a%mid%=��
if !a%nb%! == !a%upnb%! if not !a%nb%! == �� set a%nb%=��&set direction=up&call :levelup
goto backup

:down
set nb=13
:backdown
set /a nb-=1
if %nb% == 0 goto next
if !a%nb%! == �� goto backdown
set mid=%nb%
:loopdown
set /a downnb=%nb%+4
if !a%downnb%! == �� set nb=%downnb%&goto loopdown
if not %mid% == %nb% set a%nb%=!a%mid%!&set a%mid%=��
if !a%nb%! == !a%downnb%! if not !a%nb%! == �� set a%nb%=��&set direction=down&call :levelup
goto backdown

:left
set nb=1
:backleft
set /a nb+=1
if %nb% == 17 goto next
set /a leftkey=%nb%%%4
if %leftkey% == 1 goto backleft
if !a%nb%! == �� goto backleft
set mid=%nb%
:loopleft
set /a leftnb=%nb%-1
set /a rightkey=%leftnb%%%4
if %rightkey% == 0 goto loopleft2
if !a%leftnb%! == �� set nb=%leftnb%&goto loopleft
:loopleft2
if not %mid% == %nb% set a%nb%=!a%mid%!&set a%mid%=��
if !a%nb%! == !a%leftnb%! if not !a%nb%! == �� set a%nb%=��&set direction=left&call :levelup
goto backleft

:right
set nb=16
:backright
set /a nb-=1
if %nb% == 0 goto next
set /a rightkey=%nb%%%4
if %rightkey% == 0 goto backright
if !a%nb%! == �� goto backright
set mid=%nb%
:loopright
set /a rightnb=%nb%+1
set /a leftkey=%rightnb%%%4
if %leftkey% == 1 goto loopright2
if !a%rightnb%! == �� set nb=%rightnb%&goto loopright
:loopright2
if not %mid% == %nb% set a%nb%=!a%mid%!&set a%mid%=��
if !a%nb%! == !a%rightnb%! if not !a%nb%! == �� set a%nb%=��&set direction=right&call :levelup
goto backright

:levelup
set key=a!%direction%nb!
if !%key%! == �� set %key%=��&set /a score+=4&goto :eof
if !%key%! == �� set %key%=��&set /a score+=8&goto :eof
if !%key%! == �� set %key%=��&set /a score+=16&goto :eof
if !%key%! == �� set %key%=��&set /a score+=32&goto :eof
if !%key%! == �� set %key%=��&set /a score+=64&goto :eof
if !%key%! == �� set %key%=��&set /a score+=128&goto :eof
if !%key%! == �� set %key%=��&set /a score+=256&goto :eof
if !%key%! == �� set %key%=��&set /a score+=512&goto :eof
if !%key%! == �� set %key%=��&set /a score+=1024&goto :eof
if !%key%! == �� set %key%=�d&set /a score+=2048&goto :eof

:check
echo ��ĵ÷���%score%
if %score% gtr %bestscore% echo ��ߵ÷֣�&echo %score%;>save.wc
echo �����������һ��. . .
pause>nul
goto return
